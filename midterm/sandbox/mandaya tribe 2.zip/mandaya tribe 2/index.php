<!DOCTYPE html>
<html lang="en">
	<head>
		<title>The Mandaya Tribe</title>
		<meta charset="UTF-8">
		<link href="style.css" rel="stylesheet">
		
		
		
	</head>
	
	<body>
		<div id="wrap">
			<div id="header">				
					<h1 class="sitetitle">Mandaya Tribe<span class="search"><label>Search</label><input type="search" class="searchbox"></span>	</h1>
				<p>Mindanao Island</p>

				
			</div>
			
			<div id="nav">
				<ul>
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 2</a></li>
				</ul>
			</div>
			
			<div id="main">
				<h2>Background</h2>
				<p>According to the writing of John Garvan in his memoir in the New York Academy of Sciences, the 
				Mandaya is "probably the greatest and best tribe in Eastern Mindanao". Miguel Sadera-Maso writes 
				that the Mandaya "are considered by the non-Christians as the oldest and most illustrious of the 
				peoples.</p>
				
				<p>
					The ethnographic map of the Spanish colonizers shows Mandaya existence in the present provinces of Davao Oriental, Davao del Norte and Compostella Valley, and from Tago town of Surigao del Sur and Southern part of Agusan del Sur. This colorful tribe since then have underwent many influences from neo-political and economic systems. Other sub-groups emerge with names taken from their locational self-ascriptions. Among these are the Mansaka, Dibabaon, Pagsaupan, Mangguangan, Maragusan, and Dibabaon (Cole, 1913); and the Kalagan Kamayo. William A. Savage-Landor includes the Tagacaolo as a branch of the Mandaya. Presently, the concentration of the Mandaya is in Davao Oriental that lies along the Pacific Ocean. Cole (1913) avers that Mandaya is the largest tribal unit in southeastern Mindanao.
				</p>
				
				<figure class="floatFigure">
					<img src="Mandaya-Dagmay-Weavers-2.jpg" height="200" width="250">
					<figcaption>Dagmay, an abaca handwoven cloth.</figcaption>
				</figure>
				
				<h2>Culture and Arts</h2>
				<p>Undoubtedly, the Mandaya have one of the richest cultural heritage among ethnic groups. They are very close to their families. Christianized Mandaya still retain some of the past beliefs creating a syncretic form of religion.
					Undoubtedly, the Mandaya have one of the richest cultural heritage among ethnic groups. They are very close to their families. Christianized Mandaya still retain some of the past beliefs creating a syncretic form of religion.
					Mandaya also has an array of musical rendition. Instruments like kudlong, a two-stringed zither with only one string with frets, deliver music with historical, eventful, and important meanings. Kudlong is played before hunting, staging the deadly pangayao (vendetta killing) or farming. It could also be for simply entertainment. One popular instrument also is the gimball or gimbao, a large drum made using deer hide from a doe on one side and from a stag on the other side to produce different tone and pitch. 
				</p>
				
				<figure class="floatFigure">
					<img src="tradi.jpg" height="200" width="250"/>
					<figcaption>Customary laws are observed.</figcaption>
				</figure>
				<h2>Traditional Governance</h2>
				The traditional governance of the Mandaya displays a strong leadership. Customary laws are observed and stiff penalties are imposed. Acceptance and respect by the community makes a tribal governance work. In some areas, the elders and leaders approve holding of pangayao to exact justice and revenge.

       In the hinterlands, the government imposed systems in the lowlands has little effect on their practice of customary laws, however, Mandaya's have to compete with migrants from Luzon and Visayas who were brought by Americans and later, by government programs. Slowly, the ethnic people are being left behind.
			</div>
			
			<div id="sidebar">
				
				<div class="circular">
				</div>
				<div class="circular2">
				</div>
				
			</div>
			
			<div id="footer">
				<p>Copyright 2013</p>
			</div>
		</div>
		
	</body>
	
</html>